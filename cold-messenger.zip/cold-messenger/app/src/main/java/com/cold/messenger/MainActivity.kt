package com.cold.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.cold.messenger.ui.ColdApp
import com.cold.messenger.ui.theme.ColdTheme
import com.cold.messenger.ui.theme.ColdThemes

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var palette by remember { mutableStateOf(ColdThemes.Amoled) }
            ColdTheme(palette) { ColdApp(onTheme = { palette = it }) }
        }
    }
}
