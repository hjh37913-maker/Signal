package com.cold.messenger.ui.conversation

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cold.messenger.data.repository.FakeData
import com.cold.messenger.domain.messages.Message
import com.cold.messenger.ui.chats.Avatar
import com.cold.messenger.ui.theme.LocalColdPalette

private val quickReactions = listOf("❤️", "😂", "👍", "😮", "😢", "🔥")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationScreen(chatId: Long, onBack: () -> Unit) {
    val p = LocalColdPalette.current
    val chat = FakeData.chats.first { it.id == chatId }
    val messages: SnapshotStateList<Message> = remember { FakeData.messages.toMutableStateList() }
    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Message?>(null) }
    var editing by remember { mutableStateOf<Message?>(null) }
    var menuFor by remember { mutableStateOf<Message?>(null) }

    Column(Modifier.fillMaxSize().imePadding()) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(chat.title, size = 36)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(chat.title, fontSize = 16.sp)
                        Text(if (chat.online) "в мережі" else chat.username, fontSize = 12.sp, color = p.secondary)
                    }
                }
            },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = p.background),
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        HorizontalDivider(color = p.border)

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(messages, key = { it.id }) { m ->
                Bubble(m, onLongPress = { menuFor = m })
            }
        }

        replyTo?.let {
            BannerRow("Відповідь: ${it.text}") { replyTo = null }
        }
        editing?.let {
            BannerRow("Редагування: ${it.text}") { editing = null; input = "" }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { /* TODO: вибір вкладення */ }) { Icon(Icons.Default.AttachFile, "Вкладення") }
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Повідомлення…") },
                shape = RoundedCornerShape(24.dp), maxLines = 4,
            )
            IconButton(onClick = {
                val text = input.trim()
                if (text.isNotEmpty()) {
                    val e = editing
                    if (e != null) {
                        val i = messages.indexOfFirst { it.id == e.id }
                        if (i >= 0) messages[i] = e.copy(text = text, edited = true)
                        editing = null
                    } else {
                        val nextId = (messages.maxOfOrNull { it.id } ?: 0L) + 1L
                        messages.add(
                            Message(
                                id = nextId, text = text, mine = true, time = "зараз",
                                replyTo = replyTo?.text,
                            )
                        )
                        replyTo = null
                    }
                    input = ""
                }
            }) {
                Icon(
                    if (input.isBlank()) Icons.Default.Mic else Icons.AutoMirrored.Filled.Send,
                    if (input.isBlank()) "Голосове" else "Надіслати",
                )
            }
        }
    }

    menuFor?.let { m ->
        ModalBottomSheet(onDismissRequest = { menuFor = null }, containerColor = p.surface) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    quickReactions.forEach { r ->
                        TextButton(onClick = {
                            val i = messages.indexOfFirst { it.id == m.id }
                            if (i >= 0) messages[i] = m.copy(reactions = m.reactions + r)
                            menuFor = null
                        }) { Text(r, fontSize = 24.sp) }
                    }
                }
                TextButton(onClick = { replyTo = m; menuFor = null }) { Text("Відповісти") }
                if (m.mine) TextButton(onClick = { editing = m; input = m.text; menuFor = null }) { Text("Редагувати") }
                if (m.mine) TextButton(onClick = { messages.remove(m); menuFor = null }) { Text("Видалити") }
            }
        }
    }
}

@Composable
private fun BannerRow(text: String, onClose: () -> Unit) {
    val p = LocalColdPalette.current
    Row(
        Modifier.fillMaxWidth().background(p.surface).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f), maxLines = 1, fontSize = 13.sp, color = p.secondary)
        IconButton(onClose, Modifier.size(24.dp)) { Icon(Icons.Default.Close, "Скасувати") }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun Bubble(m: Message, onLongPress: () -> Unit) {
    val p = LocalColdPalette.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 300.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (m.mine) p.bubbleOut else p.bubbleIn)
                .combinedClickable(onClick = {}, onLongClick = onLongPress)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            m.replyTo?.let {
                Text("↳ $it", fontSize = 12.sp, color = p.secondary, maxLines = 1)
            }
            Text(m.text)
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                if (m.reactions.isNotEmpty()) Text(m.reactions.joinToString(""), fontSize = 13.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    (if (m.edited) "змінено · " else "") + m.time,
                    fontSize = 11.sp, color = p.secondary,
                )
            }
        }
    }
}
