package com.cold.messenger.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.cold.messenger.ui.calls.CallsScreen
import com.cold.messenger.ui.chats.ChatsScreen
import com.cold.messenger.ui.contacts.ContactsScreen
import com.cold.messenger.ui.conversation.ConversationScreen
import com.cold.messenger.ui.settings.SettingsScreen
import com.cold.messenger.ui.theme.ColdPalette
import com.cold.messenger.ui.theme.LocalColdPalette

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("chats", "Чати", Icons.Default.Chat),
    Tab("calls", "Дзвінки", Icons.Default.Call),
    Tab("contacts", "Контакти", Icons.Default.Contacts),
    Tab("settings", "Налаштування", Icons.Default.Settings),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColdApp(onTheme: (ColdPalette) -> Unit) {
    val nav = rememberNavController()
    val p = LocalColdPalette.current
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val showBar = route in tabs.map { it.route }
    var fabMenu by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = p.background,
        bottomBar = {
            if (showBar) NavigationBar(containerColor = p.surface) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo("chats"); launchSingleTop = true
                            }
                        },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
        floatingActionButton = {
            if (route == "chats") {
                Box {
                    FloatingActionButton(onClick = { fabMenu = true }, containerColor = p.accent) {
                        Icon(Icons.Default.Add, "Створити")
                    }
                    DropdownMenu(expanded = fabMenu, onDismissRequest = { fabMenu = false }) {
                        listOf("Новий чат", "Нова група", "Новий канал", "Новий контакт", "Сканувати QR").forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = { fabMenu = false })
                        }
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "chats", modifier = Modifier.padding(pad)) {
            composable("chats") { ChatsScreen { id -> nav.navigate("chat/$id") } }
            composable("calls") { CallsScreen() }
            composable("contacts") { ContactsScreen() }
            composable("settings") { SettingsScreen(onTheme) }
            composable(
                "chat/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { e ->
                ConversationScreen(e.arguments!!.getLong("id")) { nav.popBackStack() }
            }
        }
    }
}
