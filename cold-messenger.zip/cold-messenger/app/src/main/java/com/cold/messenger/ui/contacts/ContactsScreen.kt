package com.cold.messenger.ui.contacts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cold.messenger.data.repository.FakeData
import com.cold.messenger.ui.chats.Avatar
import com.cold.messenger.ui.theme.LocalColdPalette

@Composable
fun ContactsScreen() {
    val p = LocalColdPalette.current
    var query by remember { mutableStateOf("") }
    val list = FakeData.contacts.filter {
        it.name.contains(query, true) || it.username.contains(query, true)
    }
    Column(Modifier.fillMaxSize()) {
        Text("Контакти", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp))
        OutlinedTextField(
            query, { query = it },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Пошук @username") }, singleLine = true,
        )
        LazyColumn {
            items(list) { c ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(c.name, fontWeight = FontWeight.SemiBold)
                        Text(c.username, fontSize = 13.sp, color = p.secondary)
                    }
                }
            }
        }
    }
}
