package com.cold.messenger.ui.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cold.messenger.data.repository.FakeData
import com.cold.messenger.domain.messages.Chat
import com.cold.messenger.domain.messages.ChatKind
import com.cold.messenger.ui.theme.LocalColdPalette

private enum class Filter(val label: String) {
    ALL("Усі"), UNREAD("Непрочитані"), PRIVATE("Приватні"), GROUPS("Групи"), CHANNELS("Канали")
}

@Composable
fun ChatsScreen(onOpen: (Long) -> Unit) {
    var filter by remember { mutableStateOf(Filter.ALL) }
    val chats = FakeData.chats
        .filter {
            when (filter) {
                Filter.ALL -> true
                Filter.UNREAD -> it.unread > 0
                Filter.PRIVATE -> it.kind == ChatKind.PRIVATE
                Filter.GROUPS -> it.kind == ChatKind.GROUP
                Filter.CHANNELS -> it.kind == ChatKind.CHANNEL
            }
        }
        .sortedByDescending { it.pinned }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Чати", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Filter.entries) { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text(f.label) },
                    shape = RoundedCornerShape(50),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(chats, key = { it.id }) { chat -> ChatRow(chat) { onOpen(chat.id) } }
        }
    }
}

@Composable
private fun ChatRow(chat: Chat, onClick: () -> Unit) {
    val p = LocalColdPalette.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(chat.title, chat.online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (chat.pinned) Icon(Icons.Default.PushPin, null, Modifier.padding(start = 6.dp).size(14.dp), tint = p.secondary)
                if (chat.muted) Icon(Icons.Default.VolumeOff, null, Modifier.padding(start = 6.dp).size(14.dp), tint = p.secondary)
            }
            Text(chat.lastMessage, color = p.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = p.secondary, fontSize = 12.sp)
            if (chat.unread > 0) {
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier.clip(CircleShape).background(if (chat.muted) p.secondary else p.accent)
                        .defaultMinSize(20.dp, 20.dp).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(chat.unread.toString(), fontSize = 12.sp, color = p.background) }
            }
        }
    }
    HorizontalDivider(Modifier.padding(start = 76.dp), color = p.border)
}

@Composable
fun Avatar(name: String, online: Boolean = false, size: Int = 48) {
    val p = LocalColdPalette.current
    Box {
        Box(
            Modifier.size(size.dp).clip(CircleShape).background(p.surface),
            contentAlignment = Alignment.Center,
        ) { Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = p.primary) }
        if (online) Box(
            Modifier.align(Alignment.BottomEnd).size(12.dp).clip(CircleShape)
                .background(androidx.compose.ui.graphics.Color(0xFF3DDC84))
        )
    }
}
