package com.cold.messenger.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Палітра COLD: поля відповідають Custom Theme Builder з ТЗ. */
data class ColdPalette(
    val name: String,
    val isLight: Boolean,
    val background: Color,
    val surface: Color,
    val primary: Color,
    val secondary: Color,
    val accent: Color,
    val text: Color,
    val bubbleOut: Color,
    val bubbleIn: Color,
    val border: Color,
)

object ColdThemes {
    val Dark = ColdPalette(
        "Темна", false, Color(0xFF0E0F12), Color(0xFF181A1F), Color(0xFF7C9CFF),
        Color(0xFF9AA4B2), Color(0xFF5B8CFF), Color(0xFFECEFF4),
        Color(0xFF2B4A9E), Color(0xFF22252C), Color(0x22FFFFFF),
    )
    val Amoled = Dark.copy(
        name = "AMOLED Black", background = Color.Black, surface = Color(0xFF0B0B0D),
        bubbleIn = Color(0xFF16171A),
    )
    val Light = ColdPalette(
        "Світла", true, Color(0xFFF7F8FA), Color(0xFFFFFFFF), Color(0xFF2F5BFF),
        Color(0xFF5B6575), Color(0xFF2F5BFF), Color(0xFF111318),
        Color(0xFFD6E0FF), Color(0xFFEAECF1), Color(0x22000000),
    )
    val Graphite = Dark.copy(
        name = "Графіт", background = Color(0xFF1B1D21), surface = Color(0xFF25282D),
        bubbleIn = Color(0xFF2E3238),
    )
    val Ocean = Dark.copy(
        name = "Океан", background = Color(0xFF06141F), surface = Color(0xFF0C2233),
        primary = Color(0xFF4FC3F7), accent = Color(0xFF29B6F6),
        bubbleOut = Color(0xFF0B5C86), bubbleIn = Color(0xFF12304A),
    )
    val Purple = Dark.copy(
        name = "Фіолетова", background = Color(0xFF110C1A), surface = Color(0xFF1B1429),
        primary = Color(0xFFB794F6), accent = Color(0xFF9F7AEA),
        bubbleOut = Color(0xFF5B3A9E), bubbleIn = Color(0xFF261C3A),
    )
    val Red = Dark.copy(
        name = "Червона", background = Color(0xFF160B0B), surface = Color(0xFF221213),
        primary = Color(0xFFFF8A80), accent = Color(0xFFFF5252),
        bubbleOut = Color(0xFF9E2B2B), bubbleIn = Color(0xFF331A1B),
    )
    val Green = Dark.copy(
        name = "Зелена", background = Color(0xFF0A140E), surface = Color(0xFF112119),
        primary = Color(0xFF81E6A6), accent = Color(0xFF3DDC84),
        bubbleOut = Color(0xFF1F7A47), bubbleIn = Color(0xFF16301F),
    )

    val builtIn = listOf(Amoled, Dark, Light, Graphite, Ocean, Purple, Red, Green)
}

val LocalColdPalette = staticCompositionLocalOf { ColdThemes.Amoled }

@Composable
fun ColdTheme(palette: ColdPalette = ColdThemes.Amoled, content: @Composable () -> Unit) {
    val scheme = if (palette.isLight) {
        lightColorScheme(
            primary = palette.primary, secondary = palette.secondary,
            background = palette.background, surface = palette.surface,
            onBackground = palette.text, onSurface = palette.text,
            outline = palette.border,
        )
    } else {
        darkColorScheme(
            primary = palette.primary, secondary = palette.secondary,
            background = palette.background, surface = palette.surface,
            onBackground = palette.text, onSurface = palette.text,
            outline = palette.border,
        )
    }
    CompositionLocalProvider(LocalColdPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
