package com.cold.messenger.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cold.messenger.ui.chats.Avatar
import com.cold.messenger.ui.theme.ColdPalette
import com.cold.messenger.ui.theme.ColdThemes
import com.cold.messenger.ui.theme.LocalColdPalette

@Composable
fun SettingsScreen(onTheme: (ColdPalette) -> Unit) {
    val p = LocalColdPalette.current
    var readReceipts by remember { mutableStateOf(true) }
    var typing by remember { mutableStateOf(true) }
    var secure by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar("Дмитро", size = 64)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Дмитро", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("@dmytro", color = p.secondary)
                }
            }
            Spacer(Modifier.height(24.dp))
            Section("Оформлення")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ColdThemes.builtIn.forEach { t ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(t.primary)
                            .border(2.dp, if (t.name == p.name) p.text else t.border, CircleShape)
                            .clickable { onTheme(t) }
                    )
                }
            }
            Text("Тема: ${p.name}", color = p.secondary, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(20.dp))
            Section("Приватність")
            SwitchRow("Сповіщення про прочитання", readReceipts) { readReceipts = it }
            SwitchRow("Індикатор набору тексту", typing) { typing = it }
            SwitchRow("Заборонити скриншоти (FLAG_SECURE)", secure) { secure = it }
            Spacer(Modifier.height(20.dp))
            Section("Безпека")
            Text(
                "Шифрування, ключі та реєстрація поки не підключені. " +
                    "Ці екрани — лише UI-макет; реальна криптографія має йти через libsignal.",
                color = p.secondary, fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        color = LocalColdPalette.current.primary, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}
