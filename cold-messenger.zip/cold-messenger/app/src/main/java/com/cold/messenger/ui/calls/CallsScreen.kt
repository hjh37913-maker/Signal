package com.cold.messenger.ui.calls

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cold.messenger.data.repository.FakeData
import com.cold.messenger.ui.chats.Avatar
import com.cold.messenger.ui.theme.LocalColdPalette

@Composable
fun CallsScreen() {
    val p = LocalColdPalette.current
    Column(Modifier.fillMaxSize()) {
        Text("Дзвінки", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp))
        LazyColumn {
            items(FakeData.calls) { c ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold)
                        Text("${c.kind} · ${c.time}", fontSize = 13.sp,
                            color = if (c.kind == "Пропущений") Color(0xFFFF5252) else p.secondary)
                    }
                    Icon(if (c.video) Icons.Default.Videocam else Icons.Default.Call, null, tint = p.primary)
                }
            }
        }
    }
}
