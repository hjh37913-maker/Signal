package com.cold.messenger.domain.messages

enum class ChatKind { PRIVATE, GROUP, CHANNEL }

data class Message(
    val id: Long,
    val text: String,
    val mine: Boolean,
    val time: String,
    val edited: Boolean = false,
    val replyTo: String? = null,
    val reactions: List<String> = emptyList(),
)

data class Chat(
    val id: Long,
    val title: String,
    val username: String,
    val kind: ChatKind,
    val lastMessage: String,
    val time: String,
    val unread: Int = 0,
    val pinned: Boolean = false,
    val muted: Boolean = false,
    val online: Boolean = false,
)

data class CallRecord(val name: String, val time: String, val kind: String, val video: Boolean)

data class Contact(val name: String, val username: String)
