package com.cold.messenger.data.repository

import com.cold.messenger.domain.messages.CallRecord
import com.cold.messenger.domain.messages.Chat
import com.cold.messenger.domain.messages.ChatKind
import com.cold.messenger.domain.messages.Contact
import com.cold.messenger.domain.messages.Message

/**
 * ТЕСТОВІ ДАНІ ДЛЯ UI. Тут немає мережі й немає шифрування.
 * Реальний репозиторій має працювати через перевірений стек Signal (libsignal),
 * а не через власну криптографію.
 */
object FakeData {
    val chats = listOf(
        Chat(1, "Дмитро", "@dmytro", ChatKind.PRIVATE, "Побачимось увечері?", "23:12", unread = 2, pinned = true, online = true),
        Chat(2, "Команда COLD", "@cold_team", ChatKind.GROUP, "Ірина: білд готовий", "22:40", unread = 5),
        Chat(3, "Оксана", "@oksana", ChatKind.PRIVATE, "Дякую!", "21:05"),
        Chat(4, "Новини безпеки", "@sec_news", ChatKind.CHANNEL, "Оновлення Android 15", "18:30", muted = true),
        Chat(5, "Андрій", "@andriy", ChatKind.PRIVATE, "Ок, домовились", "Вчора"),
    )

    val messages = listOf(
        Message(1, "Привіт! Як справи?", false, "22:58"),
        Message(2, "Привіт, все добре. Працюю над месенджером", true, "23:00", reactions = listOf("🔥")),
        Message(3, "Круто! Покажеш?", false, "23:05", replyTo = "Працюю над месенджером"),
        Message(4, "Звісно, надішлю збірку завтра", true, "23:08", edited = true),
        Message(5, "Побачимось увечері?", false, "23:12"),
    )

    val calls = listOf(
        CallRecord("Дмитро", "Сьогодні, 20:14", "Вхідний", false),
        CallRecord("Оксана", "Сьогодні, 18:02", "Пропущений", true),
        CallRecord("Андрій", "Вчора, 12:40", "Вихідний", false),
    )

    val contacts = listOf(
        Contact("Андрій", "@andriy"),
        Contact("Дмитро", "@dmytro"),
        Contact("Ірина", "@iryna"),
        Contact("Оксана", "@oksana"),
    )
}
